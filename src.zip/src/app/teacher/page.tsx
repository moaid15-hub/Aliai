// app/teacher/page.tsx
// صفحة المعلم العراقي الذكي

'use client'

import { useState, useEffect } from 'react'

// Import components (using default imports)
import TeacherAvatar from '@/components/personas/iraqi-teacher/TeacherAvatar'
import ImageUploader from '@/components/personas/iraqi-teacher/ImageUploader'
import ImagePreview from '@/components/personas/iraqi-teacher/ImagePreview'
import GradeSelector from '@/components/personas/iraqi-teacher/GradeSelector'
import SubjectSelector from '@/components/personas/iraqi-teacher/SubjectSelector'
import TeacherChat from '@/components/personas/iraqi-teacher/TeacherChat'
import StepByStep from '@/components/personas/iraqi-teacher/StepByStep'
import ExplanationDisplay from '@/components/personas/iraqi-teacher/ExplanationDisplay'
import EncouragementBadge from '@/components/personas/iraqi-teacher/EncouragementBadge'

// Import voice components
import { TextToSpeech } from '@/components/voice/text-to-speech'
import { VoiceSearch } from '@/components/voice/voice-search'
import { ContinuousVoiceChat } from '@/components/voice/continuous-voice-chat'

// Define types locally
type IraqiGrade =
  | 'الصف الأول الابتدائي'
  | 'الصف الثاني الابتدائي'
  | 'الصف الثالث الابتدائي'
  | 'الصف الرابع الابتدائي'
  | 'الصف الخامس الابتدائي'
  | 'الصف السادس الابتدائي'
  | 'الصف الأول المتوسط'
  | 'الصف الثاني المتوسط'
  | 'الصف الثالث المتوسط'
  | 'الصف الرابع الإعدادي'
  | 'الصف الخامس الإعدادي'
  | 'الصف السادس الإعدادي'

type IraqiSubject =
  | 'الرياضيات'
  | 'العلوم'
  | 'اللغة العربية'
  | 'اللغة الإنجليزية'
  | 'التاريخ'
  | 'الجغرافية'
  | 'الفيزياء'
  | 'الكيمياء'
  | 'الأحياء'

type TeacherMood = 'happy' | 'thinking' | 'explaining' | 'encouraging'

interface ProcessingStep {
  id: number
  title: string
  description: string
  status: 'upcoming' | 'current' | 'completed'
  details: string
}

interface Message {
  id: string
  text: string
  sender: 'teacher' | 'student'
  timestamp: Date
  type?: 'text' | 'encouragement' | 'explanation'
}

export default function IraqiTeacherPage() {
  // State management
  const [selectedGrade, setSelectedGrade] = useState<IraqiGrade>('الصف السادس الابتدائي')
  const [selectedSubject, setSelectedSubject] = useState<IraqiSubject>('الرياضيات')
  const [uploadedImage, setUploadedImage] = useState<File | null>(null)
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('')
  const [currentMood, setCurrentMood] = useState<TeacherMood>('happy')
  const [explanation, setExplanation] = useState<string>('')
  const [isProcessing, setIsProcessing] = useState<boolean>(false)
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([])
  const [showEncouragement, setShowEncouragement] = useState<boolean>(false)
  const [chatMessages, setChatMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'أهلاً وسهلاً! أنا العمو حيدر، مدرس الرياضيات. شلونك اليوم؟ شنو تحتاج مساعدة؟',
      sender: 'teacher',
      timestamp: new Date(),
      type: 'text'
    }
  ])
  const [voiceError, setVoiceError] = useState<string>('')
  const [isTeacherTyping, setIsTeacherTyping] = useState(false)
  const [lastTeacherMessageId, setLastTeacherMessageId] = useState<string>('')
  const [autoPlayEnabled, setAutoPlayEnabled] = useState(true) // تشغيل تلقائي افتراضياً
  const [isTeacherSpeaking, setIsTeacherSpeaking] = useState(false) // هل المعلم يتحدث الآن
  const [voiceMode, setVoiceMode] = useState<'free' | 'premium'>('premium') // نوع الصوت

  // Teacher data
  const teacherData = {
    name: 'العمو حيدر',
    title: 'مدرس رياضيات',
    avatar: '/api/placeholder/120/120',
    status: 'online' as const,
    mood: currentMood,
    stats: {
      studentsHelped: 1250,
      questionsAnswered: 3420,
      successRate: 98
    }
  }

  // Handle image upload
  const handleImageUpload = (file: File) => {
    setUploadedImage(file)
    const url = URL.createObjectURL(file)
    setImagePreviewUrl(url)

    // Simulate processing
    simulateProcessing()
  }

  // Handle image removal
  const handleImageRemove = () => {
    if (imagePreviewUrl) {
      URL.revokeObjectURL(imagePreviewUrl)
    }
    setUploadedImage(null)
    setImagePreviewUrl('')
    setExplanation('')
    setProcessingSteps([])
  }

  // Simulate AI processing
  const simulateProcessing = () => {
    setIsProcessing(true)

    const steps: ProcessingStep[] = [
      {
        id: 1,
        title: 'تحليل الصورة',
        description: 'العمو حيدر يشوف الصورة ويحلل محتوياتها',
        status: 'current',
        details: 'استخدام تقنيات الرؤية الحاسوبية لفهم الصورة'
      },
      {
        id: 2,
        title: 'استخراج النصوص',
        description: 'قراءة النصوص والمعادلات الموجودة',
        status: 'upcoming',
        details: 'تقنية OCR لاستخراج النصوص العربية والإنجليزية'
      },
      {
        id: 3,
        title: 'فهم المسألة',
        description: 'تحليل نوع المسألة والمطلوب حلها',
        status: 'upcoming',
        details: 'الذكاء الاصطناعي يحدد نوع المسألة والاستراتيجية المناسبة'
      },
      {
        id: 4,
        title: 'إعداد الشرح',
        description: 'تحضير شرح مفصل باللهجة العراقية',
        status: 'upcoming',
        details: 'صياغة الحل بطريقة بسيطة ومفهومة'
      }
    ]

    setProcessingSteps(steps)

    // Simulate step progression
    let currentStep = 0
    const interval = setInterval(() => {
      currentStep++

      setProcessingSteps(prevSteps =>
        prevSteps.map((step, index) => ({
          ...step,
          status: index < currentStep ? 'completed' :
                 index === currentStep ? 'current' : 'upcoming'
        }))
      )

      if (currentStep >= steps.length) {
        clearInterval(interval)
        setIsProcessing(false)

        // Set sample explanation
        setExplanation(
          '**أهلاً وسهلاً حبيبي!** 👋\n\n' +
          'شفت صورتك وفهمت المسألة الي تريد حلها. هاي مسألة رياضيات حلوة!\n\n' +
          '## خلينا نحلها سوا خطوة بخطوة:\n\n' +
          '**الخطوة الأولى:** نشوف شنو معطى عندنا\n' +
          '- العدد الأول: 45\n' +
          '- العدد الثاني: 28\n' +
          '- المطلوب: الجمع\n\n' +
          '**الخطوة الثانية:** نرتب الأرقام\n\n' +
          '**الخطوة الثالثة:** نجمع من اليمين\n' +
          '- 5 + 8 = 13 (نكتب 3 ونحمل 1)\n' +
          '- 4 + 2 + 1 = 7\n\n' +
          '**النتيجة:** 73\n\n' +
          '**مبروك عليك!** 🎉 حليت المسألة صح. هذا الطريقة اسمها "الجمع بالحمل".\n\n' +
          'لو عندك أي سؤال ثاني، أنا هنا أساعدك! 😊'
        )

        setShowEncouragement(true)
      }
    }, 2000)
  }

  // Handle mood change
  const handleMoodChange = (mood: TeacherMood) => {
    setCurrentMood(mood)
  }

  // Handle sending chat messages
  const handleSendMessage = async (message: string) => {
    // إضافة رسالة الطالب
    const studentMessage: Message = {
      id: Date.now().toString(),
      text: message,
      sender: 'student',
      timestamp: new Date(),
      type: 'text'
    }
    setChatMessages(prev => [...prev, studentMessage])
    setIsTeacherTyping(true)

    try {
      // استدعاء API المحادثة
      const response = await fetch('/api/teacher/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          grade: selectedGrade,
          subject: selectedSubject,
          history: chatMessages.map(msg => ({
            role: msg.sender === 'teacher' ? 'assistant' : 'user',
            content: msg.text
          }))
        }),
      })

      if (!response.ok) {
        throw new Error('فشل في الحصول على رد')
      }

      const data = await response.json()

      // إضافة رد العمو حيدر
      const teacherResponseId = (Date.now() + 1).toString()
      const teacherResponse: Message = {
        id: teacherResponseId,
        text: data.response,
        sender: 'teacher',
        timestamp: new Date(),
        type: 'text'
      }

      setIsTeacherTyping(false)
      setChatMessages(prev => [...prev, teacherResponse])

      // تشغيل الصوت تلقائياً للرسالة الجديدة (إذا كان مفعل)
      if (autoPlayEnabled) {
        setLastTeacherMessageId(teacherResponseId)
      }

    } catch (error) {
      console.error('Chat error:', error)
      setIsTeacherTyping(false)

      // رسالة خطأ
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: 'عذراً حبيبي، صار عندي مشكلة تقنية. حاول مرة ثانية.',
        sender: 'teacher',
        timestamp: new Date(),
        type: 'text'
      }
      setChatMessages(prev => [...prev, errorMessage])
    }
  }

  // Handle voice search query
  const handleVoiceQuery = (query: string) => {
    console.log('🎤 Voice query received:', query)
    handleSendMessage(query)
  }

  // Handle voice error
  const handleVoiceError = (error: string) => {
    setVoiceError(error)
    setTimeout(() => setVoiceError(''), 5000)
  }

  // Clean up URLs on unmount
  useEffect(() => {
    return () => {
      if (imagePreviewUrl) {
        URL.revokeObjectURL(imagePreviewUrl)
      }
    }
  }, [imagePreviewUrl])

  return (
    <div className="iraqi-teacher-page">
      <div className="page-header">
        <h1 className="page-title">
          <i className="fas fa-chalkboard-teacher"></i>
          المعلم العراقي الذكي
        </h1>
        <p className="page-description">
          مرحبا بيك عند العمو حيدر! ارفع صورة السؤال وخليني أساعدك تتعلم
        </p>

        {/* زر صفحة الاختبار */}
        <div className="text-center mt-4">
          <a
            href="/test-voice"
            target="_blank"
            className="inline-block px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all font-bold text-lg"
            style={{
              background: 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)',
              boxShadow: '0 4px 12px rgba(76, 175, 80, 0.3)',
              textDecoration: 'none'
            }}
          >
            🔊 اختبار الصوت - افتح صفحة الاختبار
          </a>
        </div>
      </div>

      <div className="teacher-interface">
        {/* Teacher Avatar Section */}
        <div className="teacher-section">
          <TeacherAvatar
            {...teacherData}
            onMoodChange={handleMoodChange}
          />

          {showEncouragement && (
            <EncouragementBadge
              type="success"
              message="أحسنت! وصلت للحل الصحيح 🎉"
              onClose={() => setShowEncouragement(false)}
            />
          )}
        </div>

        {/* Controls Section */}
        <div className="controls-section">
          <div className="selectors-row">
            <GradeSelector
              selectedGrade={selectedGrade}
              onGradeSelect={setSelectedGrade}
            />

            <SubjectSelector
              selectedSubject={selectedSubject}
              onSubjectSelect={setSelectedSubject}
              selectedGrade={selectedGrade}
            />
          </div>

          <div className="upload-section">
            <ImageUploader
              onImageUpload={handleImageUpload}
              selectedGrade={selectedGrade}
              selectedSubject={selectedSubject}
            />
          </div>

          {uploadedImage && (
            <div className="preview-section">
              <ImagePreview
                imageUrl={imagePreviewUrl}
                fileName={uploadedImage.name}
                fileSize={uploadedImage.size}
                onRemove={handleImageRemove}
              />
            </div>
          )}
        </div>

        {/* Processing Section */}
        {(isProcessing || processingSteps.length > 0) && (
          <div className="processing-section">
            <StepByStep
              steps={processingSteps}
              isProcessing={isProcessing}
            />
          </div>
        )}

        {/* Explanation Section */}
        {explanation && !isProcessing && (
          <div className="explanation-section">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">الشرح</h3>
              <TextToSpeech text={explanation} className="ml-4" />
            </div>
            <ExplanationDisplay
              title="الشرح"
              content={explanation}
              dialect="baghdadi"
              isVisible={true}
            />
          </div>
        )}

        {/* Chat Section - التركيز الأساسي */}
        <div className="chat-section" style={{
          marginTop: '30px',
          padding: '20px',
          background: 'white',
          borderRadius: '15px',
          boxShadow: '0 10px 40px rgba(0,0,0,0.1)'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px',
            gap: '15px',
            flexWrap: 'wrap'
          }}>
            <h2 style={{
              fontSize: '1.5rem',
              fontWeight: 'bold',
              margin: 0,
              color: '#667eea',
              flex: '1 1 auto'
            }}>
              💬 المحادثة مع العمو حيدر
            </h2>

            {/* زر تبديل نوع الصوت */}
            <button
              onClick={() => setVoiceMode(voiceMode === 'free' ? 'premium' : 'free')}
              style={{
                padding: '8px 16px',
                background: voiceMode === 'premium'
                  ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  : 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)',
                color: 'white',
                border: 'none',
                borderRadius: '10px',
                cursor: 'pointer',
                fontWeight: '600',
                fontSize: '0.85rem',
                transition: 'all 0.3s ease',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                whiteSpace: 'nowrap',
                flex: '0 0 auto'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
              }}
              title={voiceMode === 'premium' ? 'التبديل إلى صوت مجاني' : 'التبديل إلى صوت بشري'}
            >
              {voiceMode === 'premium' ? '💎 بشري' : '🆓 مجاني'}
            </button>
          </div>

          {voiceError && (
            <div className="voice-error mb-3 p-3 bg-red-100 text-red-700 rounded-lg text-sm">
              {voiceError}
            </div>
          )}

          <TeacherChat
            messages={chatMessages}
            teacherName={teacherData.name}
            onSendMessage={handleSendMessage}
            isTyping={isTeacherTyping}
            lastTeacherMessageId={lastTeacherMessageId}
            onSpeakStart={() => setIsTeacherSpeaking(true)}
            onSpeakEnd={() => setIsTeacherSpeaking(false)}
            voiceMode={voiceMode}
          />
        </div>
      </div>
    </div>
  )
}
