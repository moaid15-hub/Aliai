// app/teacher/layout.tsx
// تخطيط صفحة المعلم

export default function TeacherLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
