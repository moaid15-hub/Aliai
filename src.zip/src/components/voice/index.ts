// Voice Components Index
export { TextToSpeech, default as TextToSpeechDefault } from './text-to-speech';
export { VoiceSearch, default as VoiceSearchDefault } from './voice-search';
