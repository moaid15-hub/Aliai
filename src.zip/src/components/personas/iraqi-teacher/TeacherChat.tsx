// components/personas/iraqi-teacher/TeacherChat.tsx
/**
 * TeacherChat Component
 * مكون محادثة المعلم العراقي
 */

import React, { useState, useRef, useEffect } from 'react';
import { TextToSpeech } from '@/components/voice/text-to-speech';
import { Mic, MicOff } from 'lucide-react';
import './TeacherChat.css';

interface Message {
  id: string;
  text: string;
  sender: 'teacher' | 'student';
  timestamp: Date;
  type?: 'text' | 'encouragement' | 'explanation';
}

interface TeacherChatProps {
  messages: Message[];
  onSendMessage?: (message: string) => void;
  isTyping?: boolean;
  teacherName?: string;
  lastTeacherMessageId?: string; // ID الرسالة الأخيرة للتشغيل التلقائي
  onSpeakStart?: () => void;
  onSpeakEnd?: () => void;
  voiceMode?: 'free' | 'premium'; // نوع الصوت
}

const TeacherChat: React.FC<TeacherChatProps> = ({
  messages,
  onSendMessage,
  isTyping = false,
  teacherName = 'الأستاذ أحمد',
  lastTeacherMessageId,
  onSpeakStart,
  onSpeakEnd,
  voiceMode = 'premium'
}) => {
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = () => {
    console.log('📤 تم الضغط على زر الإرسال');
    console.log('📝 النص:', inputValue);

    if (inputValue.trim() && onSendMessage) {
      console.log('✅ إرسال الرسالة:', inputValue.trim());
      onSendMessage(inputValue.trim());
      setInputValue('');
    } else {
      console.warn('⚠️ لا يوجد نص للإرسال');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ar-IQ', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // إعداد التعرف الصوتي
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.lang = 'ar-SA';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      console.log('🎤 سمعت:', transcript);
      setIsListening(false);

      // عرض النص لثانية ثم إرساله تلقائياً
      setInputValue(transcript);

      setTimeout(() => {
        if (transcript.trim() && onSendMessage) {
          console.log('📤 إرسال تلقائي:', transcript.trim());
          onSendMessage(transcript.trim());
          setInputValue(''); // مسح مربع النص بعد الإرسال
        }
      }, 300); // 0.3 ثانية فقط - سريع جداً
    };

    recognition.onerror = (event: any) => {
      console.error('❌ خطأ في الميكروفون:', event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  // تشغيل/إيقاف الميكروفون
  const toggleVoiceInput = () => {
    console.log('🎤 تم الضغط على زر الميكروفون');

    if (!recognitionRef.current) {
      console.error('❌ التعرف الصوتي غير مدعوم');
      alert('المتصفح لا يدعم التعرف الصوتي. جرب Chrome.');
      return;
    }

    if (isListening) {
      console.log('⏹️ إيقاف الاستماع');
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        console.log('▶️ بدء الاستماع');
        recognitionRef.current.start();
        setIsListening(true);
      } catch (error) {
        console.error('خطأ في بدء الميكروفون:', error);
        alert('خطأ في تشغيل الميكروفون. تأكد من السماح بالوصول للميكروفون.');
      }
    }
  };

  return (
    <div className="teacher-chat">
      <div className="teacher-chat__header">
        <div className="teacher-chat__teacher-info">
          <span className="teacher-chat__avatar">👨‍🏫</span>
          <div className="teacher-chat__teacher-name">
            {teacherName}
          </div>
          <div className="teacher-chat__status">
            {isTyping ? 'يكتب...' : 'متصل'}
          </div>
        </div>
      </div>

      <div className="teacher-chat__messages">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`teacher-chat__message teacher-chat__message--${message.sender}`}
          >
            <div className="teacher-chat__message-content">
              <div className="teacher-chat__message-header">
                <div className="teacher-chat__message-text">
                  {message.text}
                </div>
                {message.sender === 'teacher' && (
                  <div className="teacher-chat__message-voice">
                    <TextToSpeech
                      text={message.text}
                      className="voice-mini"
                      autoPlay={message.id === lastTeacherMessageId}
                      onSpeakStart={onSpeakStart}
                      onSpeakEnd={onSpeakEnd}
                      voiceMode={voiceMode}
                    />
                  </div>
                )}
              </div>
              <div className="teacher-chat__message-time">
                {formatTime(message.timestamp)}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="teacher-chat__message teacher-chat__message--teacher">
            <div className="teacher-chat__typing-indicator">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {onSendMessage && (
        <div className="teacher-chat__input-area">
          <textarea
            className="teacher-chat__input"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="اكتب سؤالك أو اضغط المايك..."
            rows={2}
          />

          {/* زر الميكروفون */}
          <button
            onClick={toggleVoiceInput}
            className={`teacher-chat__voice-button ${isListening ? 'listening' : ''}`}
            style={{
              padding: '12px 20px',
              background: isListening ? 'linear-gradient(135deg, #f44336 0%, #e91e63 100%)' : 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: isListening ? '0 0 20px rgba(244, 67, 54, 0.5)' : '0 4px 12px rgba(76, 175, 80, 0.3)',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
            title={isListening ? 'جاري الاستماع...' : 'التحدث بالصوت'}
          >
            {isListening ? (
              <>
                <MicOff size={20} />
                <span>استماع...</span>
              </>
            ) : (
              <>
                <Mic size={20} />
                <span>🎤 تحدث</span>
              </>
            )}
          </button>

          {/* زر الإرسال */}
          <button
            className="teacher-chat__send-button"
            onClick={handleSend}
            disabled={!inputValue.trim()}
          >
            إرسال 📤
          </button>
        </div>
      )}
    </div>
  );
};

export default TeacherChat;