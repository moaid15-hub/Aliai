// تصدير جميع الإعدادات

export * from './persona-config';

